import { useState } from 'react'
import styles from '../styles/AdminPanel.module.css'

export default function AdminPanel({ 
  responses, 
  isCollectionOpen, 
  onToggleCollection, 
  onBackToMain, 
  onClearData 
}) {
  const [exportFormat, setExportFormat] = useState('csv')

  const exportData = () => {
    if (responses.length === 0) {
      alert('No data to export')
      return
    }

    if (exportFormat === 'csv') {
      exportAsCSV()
    } else {
      exportAsJSON()
    }
  }

  const exportAsCSV = () => {
    // Get all possible keys
    const allKeys = new Set()
    responses.forEach(response => {
      Object.keys(response).forEach(key => allKeys.add(key))
    })
    
    const headers = Array.from(allKeys)
    const csvContent = [
      headers.join(','),
      ...responses.map(response => 
        headers.map(header => {
          const value = response[header] || ''
          // Escape commas and quotes in CSV
          return typeof value === 'string' && (value.includes(',') || value.includes('"')) 
            ? `"${value.replace(/"/g, '""')}"` 
            : value
        }).join(',')
      )
    ].join('\n')

    downloadFile(csvContent, 'marriage-pact-responses.csv', 'text/csv')
  }

  const exportAsJSON = () => {
    const jsonContent = JSON.stringify(responses, null, 2)
    downloadFile(jsonContent, 'marriage-pact-responses.json', 'application/json')
  }

  const downloadFile = (content, filename, mimeType) => {
    const blob = new Blob([content], { type: mimeType })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const getStats = () => {
    if (responses.length === 0) return {}
    
    const ages = responses.map(r => parseInt(r.age)).filter(age => !isNaN(age))
    const years = responses.reduce((acc, r) => {
      acc[r.year] = (acc[r.year] || 0) + 1
      return acc
    }, {})
    
    const majors = responses.reduce((acc, r) => {
      acc[r.major] = (acc[r.major] || 0) + 1
      return acc
    }, {})

    return {
      totalResponses: responses.length,
      avgAge: ages.length > 0 ? (ages.reduce((a, b) => a + b, 0) / ages.length).toFixed(1) : 'N/A',
      yearDistribution: years,
      topMajors: Object.entries(majors).sort((a, b) => b[1] - a[1]).slice(0, 5)
    }
  }

  const stats = getStats()

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h2>📊 Admin Dashboard</h2>
        <button onClick={onBackToMain} className={styles.backBtn}>
          ← Back to Main
        </button>
      </div>

      <div className={styles.statusCard}>
        <div className={styles.statusHeader}>
          <h3>Collection Status</h3>
          <div className={`${styles.statusIndicator} ${isCollectionOpen ? styles.open : styles.closed}`}>
            {isCollectionOpen ? '🟢 Open' : '🔴 Closed'}
          </div>
        </div>
        <button onClick={onToggleCollection} className={styles.toggleBtn}>
          {isCollectionOpen ? 'Close Collection' : 'Reopen Collection'}
        </button>
      </div>

      <div className={styles.statsGrid}>
        <div className={styles.statCard}>
          <h3>Total Responses</h3>
          <div className={styles.statNumber}>{stats.totalResponses}</div>
        </div>
        
        <div className={styles.statCard}>
          <h3>Average Age</h3>
          <div className={styles.statNumber}>{stats.avgAge}</div>
        </div>
        
        <div className={styles.statCard}>
          <h3>Most Recent</h3>
          <div className={styles.statText}>
            {responses.length > 0 ? 
              new Date(responses[responses.length - 1].timestamp).toLocaleDateString() : 
              'No responses yet'
            }
          </div>
        </div>
      </div>

      {responses.length > 0 && (
        <>
          <div className={styles.distributionCard}>
            <h3>Year Distribution</h3>
            <div className={styles.distribution}>
              {Object.entries(stats.yearDistribution).map(([year, count]) => (
                <div key={year} className={styles.distributionItem}>
                  <span>{year}</span>
                  <span>{count}</span>
                </div>
              ))}
            </div>
          </div>

          <div className={styles.distributionCard}>
            <h3>Top Majors</h3>
            <div className={styles.distribution}>
              {stats.topMajors.map(([major, count]) => (
                <div key={major} className={styles.distributionItem}>
                  <span>{major}</span>
                  <span>{count}</span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      <div className={styles.exportCard}>
        <h3>Export Data</h3>
        <div className={styles.exportControls}>
          <select 
            value={exportFormat} 
            onChange={(e) => setExportFormat(e.target.value)}
            className={styles.formatSelect}
          >
            <option value="csv">CSV (Excel compatible)</option>
            <option value="json">JSON (for programming)</option>
          </select>
          <button onClick={exportData} className={styles.exportBtn}>
            📥 Export {responses.length} Responses
          </button>
        </div>
        <p className={styles.exportNote}>
          CSV format is recommended for analysis in Excel, R, or Python
        </p>
      </div>

      <div className={styles.dangerZone}>
        <h3>⚠️ Danger Zone</h3>
        <button onClick={onClearData} className={styles.clearBtn}>
          🗑️ Clear All Data
        </button>
        <p className={styles.warningText}>
          This will permanently delete all responses. Use only for testing.
        </p>
      </div>

      {responses.length > 0 && (
        <div className={styles.recentResponses}>
          <h3>Recent Responses</h3>
          <div className={styles.responsesList}>
            {responses.slice(-10).reverse().map((response, index) => (
              <div key={response.id} className={styles.responseItem}>
                <div className={styles.responseHeader}>
                  <strong>{response.name}</strong>
                  <span className={styles.responseTime}>
                    {new Date(response.timestamp).toLocaleString()}
                  </span>
                </div>
                <div className={styles.responseDetails}>
                  {response.age} years old • {response.year} • {response.major}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}